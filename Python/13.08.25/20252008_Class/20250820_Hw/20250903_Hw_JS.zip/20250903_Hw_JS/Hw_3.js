let currentNumber = 1;
const maxNumber = 25;

while (currentNumber <= maxNumber) {
  console.log(currentNumber);
  currentNumber++;
}
