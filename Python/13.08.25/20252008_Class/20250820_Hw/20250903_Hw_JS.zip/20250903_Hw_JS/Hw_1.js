function displayNumber() {
const number = document.getElementById('numberInput').value;
document.getElementById('output').textContent = `Ты ввел ${number}`;
        }