let number = prompt("Введите число:");
console.log(`Ты ввел ${number}`);
