let mystr = 'nice';
for (let i = 0; i < mystr.length; i++) {
    console.log(mystr[i]);
}