let array = ['Ася', 'Вася', 'Мася'];
let position = array.indexOf('Ася');
console.log(position);