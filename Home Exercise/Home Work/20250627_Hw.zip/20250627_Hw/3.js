const str = 'ваша строка';
console.log(str.length);