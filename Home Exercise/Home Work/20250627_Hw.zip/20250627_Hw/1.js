let academy = 'TOP';
let position = academy.indexOf('P') + 1;
console.log(position);