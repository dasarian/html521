function issum(a, b, c) {
    return a + b === c;
}

console.log(issum(2, 3, 5)); 
console.log(issum(2, 3, 6)); 
