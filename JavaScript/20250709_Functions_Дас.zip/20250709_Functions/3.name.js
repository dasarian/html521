function sayHello(name) {
    console.log("Привет, " + name + "!");
}

sayHello("Алексей"); 
