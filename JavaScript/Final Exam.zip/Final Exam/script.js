console.log("Всё будет хорошо");

