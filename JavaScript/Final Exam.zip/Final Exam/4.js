function viju() {
    console.log("Всё будет хорошо");
}