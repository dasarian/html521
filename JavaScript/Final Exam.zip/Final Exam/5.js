function vihu(inputElement) {
    console.log("Текущее значение:", inputElement.value);
}