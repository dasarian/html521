function viju() {
    console.log("Функция viju выполнена");
}


